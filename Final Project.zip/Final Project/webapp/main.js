

angular.module('KRRclass', [ 'chart.js']).controller('MainCtrl', ['$scope','$http', mainCtrl]);

function mainCtrl($scope, $http){



	$scope.startMyAwesomeApp = function(){

		document.getElementById('wrapper').innerHTML = '<tr><th>Please wait while we are searching for Cocktails, this may take some time</th></tr>';

		switch(true) {
		case /nothing/.test($scope.selectedIngredient1):
		var ingredient1URI = "";
		break;
		case /WhiteRum/.test($scope.selectedIngredient1):
		var ingredient1URI = "white rum";
		break;
		case /Vodka/.test($scope.selectedIngredient1):
		var ingredient1URI = "vodka";
		break;
		case /Whisky/.test($scope.selectedIngredient1):
		var ingredient1URI = "whisky";
		break;
		case /Rum/.test($scope.selectedIngredient1):
		var ingredient1URI = "rum";
		break;
		case /Aguardiente/.test($scope.selectedIngredient1):
		var ingredient1URI = "aguardiente";
		break;
		case /Tequila/.test($scope.selectedIngredient1):
		var ingredient1URI = "tequila";
		break;
		case /Absinthe/.test($scope.selectedIngredient1):
		var ingredient1URI = "absinthe";
		break;
		case /Gin/.test($scope.selectedIngredient1):
		var ingredient1URI = "gin";
		break;
		case /Moonshine/.test($scope.selectedIngredient1):
		var ingredient1URI = "moonshine";
		break;
		case /Jenever/.test($scope.selectedIngredient1):
		var ingredient1URI = "Jenever";
		break;
		case /Cachaça/.test($scope.selectedIngredient1):
		var ingredient1URI = "cachaça";
		break;
		case /TripleSec/.test($scope.selectedIngredient1):
		var ingredient1URI = "triple sec";
		break;
		case /ScotchWhisky/.test($scope.selectedIngredient1):
		var ingredient1URI = "Scotch whisky";
		break;
		case /DarkRum/.test($scope.selectedIngredient1):
		var ingredient1URI = "dark rum";
		break;
		case /Curaçao/.test($scope.selectedIngredient1):
		var ingredient1URI = "Curaçao";
		break;
		case /amaretto/.test($scope.selectedIngredient1):
		var ingredient1URI = "amaretto";
		break;
		case /Beer/.test($scope.selectedIngredient1):
		var ingredient1URI = "Beer";
		break;
		case /Wine/.test($scope.selectedIngredient1):
		var ingredient1URI = "Wine";
		break;
		case /Vermouth/.test($scope.selectedIngredient1):
		var ingredient1URI = "Vermouth";
		break;
		case /Prosecco/.test($scope.selectedIngredient1):
		var ingredient1URI = "Prosecco";
		break;
		case /Jägermeister/.test($scope.selectedIngredient1):
		var ingredient1URI = "Jägermeister";
		break;
		case /Cointreau/.test($scope.selectedIngredient1):
		var ingredient1URI = "Cointreau";
		break;
		case /crèmeDeMenthe/.test($scope.selectedIngredient1):
		var ingredient1URI = "crème de menthe";
		break;
		case /Maraschino/.test($scope.selectedIngredient1):
		var ingredient1URI = "Maraschino";
		break;
		} ;

		switch(true) {
		case /nothing/.test($scope.selectedIngredient3):
		var ingredient3URI = "";
		break;
		case /Honey/.test($scope.selectedIngredient3):
		var ingredient3URI = "honey";
		break;
		case /LimeJuice/.test($scope.selectedIngredient3):
		var ingredient3URI = "lime juice";
		break;
		case /Cream/.test($scope.selectedIngredient3):
		var ingredient3URI = "cream";
		break;
		case /EggWhite/.test($scope.selectedIngredient3):
		var ingredient3URI = "Egg white";
		break;
		case /Pineapple/.test($scope.selectedIngredient3):
		var ingredient3URI = "pineapple";
		break;
		case /Sugar/.test($scope.selectedIngredient3):
		var ingredient3URI = "sugar";
		break;
		case /Ice cream/.test($scope.selectedIngredient3):
		var ingredient3URI = "ice cream";
		break;
		case /Grenadine/.test($scope.selectedIngredient3):
		var ingredient3URI = "grenadine";
		break;
		case /Cinnamon/.test($scope.selectedIngredient3):
		var ingredient3URI = "cinnamon";
		break;
		case /Butter/.test($scope.selectedIngredient3):
		var ingredient3URI = "butter";
		break;
		case /Carrot Juice/.test($scope.selectedIngredient3):
		var ingredient3URI = "Carrot juice";
		break;
		case /Cranberry Juice/.test($scope.selectedIngredient3):
		var ingredient3URI = "Cranberry juice";
		break;
		case /Ginger/.test($scope.selectedIngredient3):
		var ingredient3URI = "ginger";
		break;
		case /Syrup/.test($scope.selectedIngredient3):
		var ingredient3URI = "syrup";
		break;
		case /Chili Pepper/.test($scope.selectedIngredient3):
		var ingredient3URI = "Chili pepper";
		break;
		case /Blackberry/.test($scope.selectedIngredient3):
		var ingredient3URI = "blackberry";
		break;
		case /Tomato/.test($scope.selectedIngredient3):
		var ingredient3URI = "tomato";
		break;
		case /Tabaso Sauce/.test($scope.selectedIngredient3):
		var ingredient3URI = "Tabasco sauce";
		break;
		case /Lemonade/.test($scope.selectedIngredient3):
		var ingredient3URI = "lemonade";
		break;
		case /Milk/.test($scope.selectedIngredient3):
		var ingredient3URI = "milk";
		break;
		case /Whipped Cream/.test($scope.selectedIngredient3):
		var ingredient3URI = "whipped cream";
		break;
		case /Letuce/.test($scope.selectedIngredient3):
		var ingredient3URI = "lettuce";
		break;
		case /Coconut Milk/.test($scope.selectedIngredient3):
		var ingredient3URI = "coconut milk";
		break;
		case /Frozen Banana/.test($scope.selectedIngredient3):
		var ingredient3URI = "frozen banana";
		break;
		case /Salt/.test($scope.selectedIngredient3):
		var ingredient3URI = "salt";
		break;
		case /Nutmeg/.test($scope.selectedIngredient3):
		var ingredient3URI = "nutmeg";
		break;
		case /Lime/.test($scope.selectedIngredient3):
		var ingredient3URI = "lime";
		break;
		case /Water/.test($scope.selectedIngredient3):
		var ingredient3URI = "water";
		break;
		case /Celerly Stalk/.test($scope.selectedIngredient3):
		var ingredient3URI = "celery stalk";
		break;
		case /Worcestershire Sauce/.test($scope.selectedIngredient3):
		var ingredient3URI = "Worcestershire sauce";
		break;
		} ;


		switch(true) {
		case /nothing/.test($scope.selectedIngredient2):
		var ingredient2URI = "";
		break;
		case /Honey/.test($scope.selectedIngredient2):
		var ingredient2URI = "honey";
		break;
		case /LimeJuice/.test($scope.selectedIngredient2):
		var ingredient2URI = "lime juice";
		break;
		case /Cream/.test($scope.selectedIngredient2):
		var ingredient2URI = "cream";
		break;
		case /EggWhite/.test($scope.selectedIngredient2):
		var ingredient2URI = "Egg white";
		break;
		case /Pineapple/.test($scope.selectedIngredient2):
		var ingredient2URI = "pineapple";
		break;
		case /Sugar/.test($scope.selectedIngredient2):
		var ingredient2URI = "sugar";
		break;
		case /Ice cream/.test($scope.selectedIngredient2):
		var ingredient2URI = "ice cream";
		break;
		case /Grenadine/.test($scope.selectedIngredient2):
		var ingredient2URI = "grenadine";
		break;
		case /Cinnamon/.test($scope.selectedIngredient2):
		var ingredient2URI = "cinnamon";
		break;
		case /Butter/.test($scope.selectedIngredient2):
		var ingredient2URI = "butter";
		break;
		case /Carrot Juice/.test($scope.selectedIngredient2):
		var ingredient2URI = "Carrot juice";
		break;
		case /Cranberry Juice/.test($scope.selectedIngredient2):
		var ingredient2URI = "Cranberry juice";
		break;
		case /Ginger/.test($scope.selectedIngredient2):
		var ingredient2URI = "ginger";
		break;
		case /Syrup/.test($scope.selectedIngredient2):
		var ingredient2URI = "syrup";
		break;
		case /Chili Pepper/.test($scope.selectedIngredient2):
		var ingredient2URI = "Chili pepper";
		break;
		case /Blackberry/.test($scope.selectedIngredient2):
		var ingredient2URI = "blackberry";
		break;
		case /Tomato/.test($scope.selectedIngredient2):
		var ingredient2URI = "tomato";
		break;
		case /Tabaso Sauce/.test($scope.selectedIngredient2):
		var ingredient2URI = "Tabasco sauce";
		break;
		case /Lemonade/.test($scope.selectedIngredient2):
		var ingredient2URI = "lemonade";
		break;
		case /Milk/.test($scope.selectedIngredient2):
		var ingredient2URI = "milk";
		break;
		case /Whipped Cream/.test($scope.selectedIngredient2):
		var ingredient2URI = "whipped cream";
		break;
		case /Letuce/.test($scope.selectedIngredient2):
		var ingredient2URI = "lettuce";
		break;
		case /Coconut Milk/.test($scope.selectedIngredient2):
		var ingredient2URI = "coconut milk";
		break;
		case /Frozen Banana/.test($scope.selectedIngredient2):
		var ingredient2URI = "frozen banana";
		break;
		case /Salt/.test($scope.selectedIngredient2):
		var ingredient2URI = "salt";
		break;
		case /Nutmeg/.test($scope.selectedIngredient2):
		var ingredient2URI = "nutmeg";
		break;
		case /Lime/.test($scope.selectedIngredient2):
		var ingredient2URI = "lime";
		break;
		case /Water/.test($scope.selectedIngredient2):
		var ingredient2URI = "water";
		break;
		case /Celerly Stalk/.test($scope.selectedIngredient2):
		var ingredient2URI = "celery stalk";
		break;
		case /Worcestershire Sauce/.test($scope.selectedIngredient2):
		var ingredient2URI = "Worcestershire sauce";
		break;

		} ;



		$scope.myDisplayMessage = "Welcome to my awesome Web Application called: " + $scope.myInputAppName ;
		$scope.mySparqlEndpoint = "http://192.168.178.26:7200/repositories/Final_Project_Triplestore" ; //change the Endpoint here
		$scope.mySparqlQuery =  encodeURI(`PREFIX ex: <http://www.example.org/CocktailOntology/>
																								select DISTINCT (STR(?label) as ?cocktailLabel) ?image (STR(?allingredientsLabel) as ?testlabel) (STR(?garnishLabel) as ?garnishlabel) (STR(?glassLabel) as ?glasslabel) ?instruction

																											 where {
																																		?Cocktail ex:hasAlcoholicIngredient ?ingredient1 ;
																																							ex:hasLabel ?label ;
																																							ex:hasIngredient ?ingredient3 ;
																																							ex:hasIngredient ?ingredient2 ;
																																							ex:hasIngredient ?allingredients ;


																																							OPTIONAL{?Cocktail ex:hasImage ?image.}
																																							OPTIONAL{?Cocktail ex:hasGarnish ?garnish .
																																							?garnish ex:hasLabel ?garnishLabel.}
																																							OPTIONAL{?Cocktail ex:hasGlass ?glass .
																																							?glass ex:hasLabel ?glassLabel.}
																																							OPTIONAL{?Cocktail ex:hasInstruction ?instruction .}



																																		?ingredient1 ex:hasLabel ?ingredient1Label.
																																		?ingredient2 ex:hasLabel ?ingredient2Label.
																																		?ingredient3 ex:hasLabel ?ingredient3Label.
																																		?allingredients ex:hasLabel ?allingredientsLabel.


																																		filter contains(STR(?ingredient1Label), "${ingredient1URI}")
																																		filter contains(STR(?ingredient2Label), "${ingredient2URI}")
																																		filter contains(STR(?ingredient3Label), "${ingredient3URI}")

																									}



																									`).replace(/#/g, '%23') ;

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.mySparqlQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			$scope.myDynamicLabels = [];
			$scope.myDynamicImages = [];
			$scope.myDynamicInstructions = [];
			$scope.temparr2 = [];
			$scope.greatarr2 = [];
			$scope.temparr = [];
			$scope.greatarr = [];
			$scope.temparr3 = [];
			$scope.greatarr3 = [];
			$scope.counter = 0;

			console.log(data)

			// now iterate on the results
			angular.forEach(data.results.bindings, function(val) {
					//console.log($scope.myDynamicLabels)


			$scope.counter += 1

			//		console.log($scope.counter)
			//		console.log(val.allingredientscount.value)



			if($scope.counter < data.results.bindings.length) {

				if($.inArray(val.cocktailLabel.value, $scope.myDynamicLabels) === -1){


						$scope.greatarr.push($scope.temparr)
						$scope.greatarr2.push($scope.temparr2)
						$scope.greatarr3.push($scope.temparr3)
						$scope.temparr = []
						$scope.temparr2 = []
						$scope.temparr3 = []
						$scope.myDynamicLabels.push(val.cocktailLabel.value)
						if($.inArray(val.testlabel.value, $scope.temparr) === -1) $scope.temparr.push(val.testlabel.value)


					if (val.image === undefined){
							$scope.myDynamicImages.push("no img");
					}

					else{
							if($.inArray(val.image.value, $scope.myDynamicImages) === -1) $scope.myDynamicImages.push(val.image.value)
					}

					if (val.garnishlabel === undefined){
							if($.inArray("no garnish available", $scope.temparr2) === -1) $scope.temparr2.push("no garnish available");
					}

					else{
							if($.inArray(val.garnishlabel.value, $scope.temparr2) === -1) $scope.temparr2.push(val.garnishlabel.value)
					}

					if (val.glasslabel === undefined){
							if($.inArray("no glass available", $scope.temparr3) === -1) $scope.temparr3.push("no glass available");
					}

					else{
							if($.inArray(val.glasslabel.value, $scope.temparr3) === -1) $scope.temparr3.push(val.glasslabel.value)
					}

					if (val.instruction === undefined){
							$scope.myDynamicInstructions.push("no instruction available");
					}

					else{
							if($.inArray(val.instruction.value, $scope.myDynamicInstructions) === -1) $scope.myDynamicInstructions.push(val.instruction.value)
					}

				}

				else{
					if($.inArray(val.testlabel.value, $scope.temparr) === -1) $scope.temparr.push(val.testlabel.value)

					if (val.garnishlabel === undefined){
							if($.inArray("no garnish available", $scope.temparr2) === -1) $scope.temparr2.push("no garnish available");
					}

					else{
							if($.inArray(val.garnishlabel.value, $scope.temparr2) === -1) $scope.temparr2.push(val.garnishlabel.value)
					}

					if (val.glasslabel === undefined){
							if($.inArray("no glass available", $scope.temparr3) === -1) $scope.temparr3.push("no glass available");
					}

					else{
							if($.inArray(val.glasslabel.value, $scope.temparr3) === -1) $scope.temparr3.push(val.glasslabel.value)
					}

				}

			}

			else {
				$scope.greatarr.push($scope.temparr)
				$scope.greatarr2.push($scope.temparr2)
				$scope.greatarr3.push($scope.temparr3)

			}

			});
			var len = $scope.myDynamicLabels.length;
			var cocktail_label = $scope.myDynamicLabels;
			var cocktail_image = $scope.myDynamicImages;
			var cocktail_ingredients = $scope.greatarr;
			var cocktail_garnish = $scope.greatarr2;
			var cocktail_glass = $scope.greatarr3;
			var cocktail_instruction = $scope.myDynamicInstructions;



			createTable(len, cocktail_label, cocktail_image, cocktail_ingredients, cocktail_garnish, cocktail_glass, cocktail_instruction);

		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

}

function createTable(len, cocktail_label, cocktail_image, cocktail_ingredients, garnish, glass, instruction){
	var num_rows = len;

	if(num_rows == 0){
		document.getElementById('wrapper').innerHTML = '<p style="color:white;">There were no cocktails found with this combination of ingredients, please try another combination</p>'
	}

	else{

	var theader = '<table border="1">\n';
	var tbody = '';
	tbody += '<tr>';

		tbody += '<th>';
		tbody += "Cocktail"
		tbody += '</th>'
		tbody += '<th>';
		tbody += "Image"
		tbody += '</th>'
		tbody += '<th>';
		tbody += "Ingredient"
		tbody += '</th>'
		tbody += '<th>';
		tbody += "Garnish"
		tbody += '</th>'
		tbody += '<th>';
		tbody += "Glass"
		tbody += '</th>'
		tbody += '<th>';
		tbody += "Instruction"
		tbody += '</th>';
		tbody += '</tr>';

	for(var i=0; i<len; i++)
	{

			tbody += '<tr>';


					tbody += '<td>';
					tbody += (i+1)+". "  + cocktail_label[i];
					tbody += '</td>';
					tbody += '<td>';
					tbody += '<img src="' + cocktail_image[i] + '" alt="image not available">';
					tbody += '</td>';
					tbody += '<td>';
					tbody += cocktail_ingredients[i+1];
					tbody += '</td>';
					tbody += '<td>';
					tbody += garnish[i + 1];
					tbody += '</td>';
					tbody += '<td>';
					tbody += glass[i + 1];
					tbody += '</td>';
					tbody += '<td>';
					tbody += instruction[i];
					tbody += '</td>';
					tbody += '</tr>\n';
	}

	var tfooter = '</table>';
	document.getElementById('wrapper').innerHTML = theader + tbody + tfooter;
}
}
