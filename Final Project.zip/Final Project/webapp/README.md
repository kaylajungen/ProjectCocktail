# Tutorial: Using our Awesome WebApp about Cocktails

In order to be able to run the application the first step is to download our ontology.
Now go to graphdb and create a new repository which can be called whatever you would like.
The newly created repository should be selected as active repository.  
Now go to import and select rdf.Here you will be able to upload a rdf file.
Now go ahead and upload our ontology which is a ttl file.
Now select 'import', now our ontology will be uploaded to the repository.
Now copy the repository url and open up our http://main.js file in a text editor such as atom or visual studio code.
In the http://main.js file go to $scope.mySparqlEndpoint (at line 288) and set the repository url as $scope.mySparqlEndpoint.
Now you should be able to open the index page and use our applicationIn order for the results to show, all the select buttons must select something.
The select button can select 'cannot decide', but there must be something selected.
If you select cannot decide for every ingredient, graphdb might not have the computation power to show the results.
This is due to the fact that the number of cocktails is very high, and the combinations with all ingredients and glasses will result into a very high number of results.
Don't forget to Have fun while using the app (:
